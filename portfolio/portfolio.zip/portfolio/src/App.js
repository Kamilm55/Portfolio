import Header from "./components/Header";
import {ChakraProvider} from "@chakra-ui/react"
import React from "react";
import LandingSection from "./components/LandingSection";
import 'bootstrap/dist/css/bootstrap.min.css'
import ProjectsSection from "./components/ProjectsSection";
import ContactMeSection from "./components/ContactMeSection";
import {AlertProvider} from "./context/alertContext"
import Footer from "./components/Footer";

function App() {
  return (
      <ChakraProvider>
            <Header />
            <LandingSection />
            <ProjectsSection />
        <AlertProvider>
            <ContactMeSection />
        </AlertProvider>
        <Footer />
      </ChakraProvider>
  );
}

export default App;
